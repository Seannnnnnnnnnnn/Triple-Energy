// Hamburger Menu
function openBtn(){
    document.getElementById("menu").style.width = "100vw"
}

function closeBtn(){
    document.getElementById("menu").style.width = "0"
}